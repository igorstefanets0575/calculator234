﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.CodeDom;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace BogdanStudios
{
    public partial class Form2 : Form
    {
     

        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 fr1 = new Form1(); // Виконуємо вихід на голвну форму
            fr1.Show();
            Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
             //Провіряєм кількість вибранмх рядкув
            if (dataGridView1.SelectedRows.Count != 1)
            {
                MessageBox.Show("Виберіть один рядок!", "Увага!");
                return;
            }

            //Заповнюємо вибраний рядок
            int index = dataGridView1.SelectedRows[0].Index;

            //Провіряєм дані в таблиці
            if (dataGridView1.Rows[index].Cells[0].Value == null)
            {
                MessageBox.Show("Не Всі дані введені!", "Увага!");
                return;
            }

            //Читаєм дані
            string id = dataGridView1.Rows[index].Cells[0].Value.ToString();

            //Створюємо з'єднання
            string connectionString = "provider=Microsoft.Jet.OLEDB.12.0;Data Source=Kontora.accdb";//рядок підключення
            OleDbConnection dbConnection = new OleDbConnection(connectionString);//створюємо підключення

            //Виконуємо запит БД
            
            string query = "DELETE FROM table_name WHERE id = " + id;//рядок запиту
            OleDbCommand dbCommand = new OleDbCommand(query, dbConnection);//команда

            //Виконуємо запит
           
            {
                MessageBox.Show("Данні успішно видалені!", "Увага!");
                //Видалення даних з таблиців формі
                dataGridView1.Rows.RemoveAt(index);
            }

           
        
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.клієнтиTableAdapter.Update(this.kontoraDataSet.Клієнти);  // збереження даних в формі
            
        }

        private void Update(KontoraDataSet kontoraDataSet)
        {
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kontoraDataSet.Клієнти' table. You can move, or remove it, as needed.
            this.клієнтиTableAdapter.Fill(this.kontoraDataSet.Клієнти); //  Відображення даних з БД

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            клієнтиBindingSource.Filter = "№ паспорта=\'" + toolStripTextBox1 + "\'";
        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            клієнтиBindingSource.Filter = null;
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }
    }
}
